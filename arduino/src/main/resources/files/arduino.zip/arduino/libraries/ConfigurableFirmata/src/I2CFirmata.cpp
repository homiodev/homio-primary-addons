/*
 * Implementation is in I2CFirmata.h to avoid having to include Wire.h in all
 * sketch files that include ConfigurableFirmata.h
 */
